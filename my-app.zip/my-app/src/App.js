import { useState } from 'react';
import './App.css';
import About from './components/About';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import Alert from './components/Alert';
import Login from './components/Login';
import Register from './components/Register';
import Home from './components/Home';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ForgetPassword from './components/ForgetPassword';
import Otp from './components/Otp';
import ResetPassword from './components/ResetPassword';
import ChangePassword from './components/ChangePassword';
import Table from './components/Table';
import Profile from './components/Profile';
import Edit from './components/Edit';
import Test from './components/Test';
import Userprofile from './components/Userprofile';
import UserInfo from './components/UserInfo';

function App() {
    const [mode, setMode] = useState('light'); //whether check dark mode enable or not
    const [alert, setAlert] = useState(null);
    const [refreshApp, setRefreshApp] = useState(false);
    const status = localStorage.getItem('status');

    const refresh = () => {
        setRefreshApp(!refreshApp);
        // navigate(`/login`);
    }
    const showAlert = (message, type) => {
        setAlert({
            msg: message,
            Type: type
        })
        setTimeout(() => {
            setAlert(null)
        }, 1500)
    }

    const toggleMode = () => {
        if (mode === 'light') {
            setMode('dark');
            document.body.style.backgroundColor = '#042745';
            showAlert("Dark mode has been enable", "success")

        } else {
            setMode('light')
            document.body.style.backgroundColor = 'white';
            showAlert("Light mode has been enable", "success")

        }
    }

    return (
        <BrowserRouter>
            <>
                <Navbar title="React Project" mode={mode} toggleMode={toggleMode} />
                <Alert alert={alert} />
                <div className="container">
                    <Routes>
                        {
                            status ?
                                <>
                                    <Route exact path="/dashboard" element={<Dashboard showAlert={showAlert} heading="Enter the text to analyze" name="Dashboard" mode={mode} toggleMode={toggleMode} />} />

                                    <Route exact path="/profile" element={<Profile showAlert={showAlert} name="Profile" />} />

                                    <Route exact path="/changepassword" element={<ChangePassword showAlert={showAlert} name="Change Password" />} />

                                    <Route exact path="/userprofile" element={<Userprofile showAlert={showAlert} name="User Profile" />} />

                                    <Route exact path="/table" element={<Table showAlert={showAlert} name="Table" />} />

                                    <Route exact path="/edit" element={<Edit mode={mode} toggleMode={toggleMode} showAlert={showAlert} name="Edit" />} />

                                    <Route exact path="/" element={<Home mode={mode} toggleMode={toggleMode} showAlert={showAlert} name="Home" />} />

                                    <Route exact path="/about" element={<About mode={mode} toggleMode={toggleMode} name="About" />} />
                                    <Route exact path="/userinfo" element={<UserInfo mode={mode} refresh={refresh} toggleMode={toggleMode} name="About" />} />

                                </>
                                :
                                <>
                                    <Route exact path="/about" element={<About mode={mode} toggleMode={toggleMode} name="About" />} />

                                    <Route exact path="/login" element={<Login showAlert={showAlert} name="Login" />} />

                                    <Route exact path="/forgetpassword" element={<ForgetPassword showAlert={showAlert} name="Forget Password" />} />

                                    <Route exact path="/otp" element={<Otp showAlert={showAlert} name="verification OTP" />} />

                                    <Route exact path="/resetpassword" element={<ResetPassword showAlert={showAlert} name="Reset Password" />} />

                                    <Route exact path="/register" element={<Register showAlert={showAlert} name="Register" />} />

                                    <Route exact path="/" element={<Home mode={mode} toggleMode={toggleMode} showAlert={showAlert} name="Home" />} />

                                    <Route exact path="/test" element={<Test mode={mode} toggleMode={toggleMode} showAlert={showAlert} name="Test" />} />
                                </>
                        }

                    </Routes>
                </div>
            </>
        </BrowserRouter>
    );
}

export default App;
