import React from 'react';

export default function Userprofile() {
    const DataForView = JSON.parse(localStorage.getItem('userDetailsView'));

    // console.log("data >>>", DataForView)

    return (
        <>
            <div>
                <h1>
                    Profile Settings
                </h1>
            </div>

            <nav className='my-5'>
                <div className="nav nav-tabs" id="nav-tab" role="tablist">
                    <button className="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Profile</button>
                </div>
            </nav>

            <div className="tab-content" id="nav-tabContent">
                <div className="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">

                    <div className="student-profile py-4">
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-4">
                                    <div className="card shadow-sm">
                                        <div className="card-header bg-transparent text-center">
                                            <img className="profile_img" src="https://source.unsplash.com/600x300/?student" alt="student dp" style={{ width: "300px" }} />
                                            <h3>{DataForView.name}</h3>
                                        </div>
                                        <div className="card-body">
                                            <p className="mb-0"><strong className="pr-1">ID : </strong>{DataForView.id}</p>
                                            <p className="mb-0"><strong className="pr-1">Status : </strong>{DataForView.status}</p>
                                            <p className="mb-0"><strong className="pr-1">Role: </strong>{DataForView.role}</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-8">
                                    <div className="card shadow-sm">
                                        <div className="card-header bg-transparent border-0">
                                            <h3 className="mb-0"><i className="far fa-clone pr-1"></i>General Information</h3>
                                        </div>
                                        <div className="card-body pt-0">
                                            <table className="table table-bordered">
                                                <tr>
                                                    <th width={"30%"}>Name</th>
                                                    <td width={"2%"}>:</td>
                                                    <td>{DataForView.name}</td>
                                                </tr>
                                                <tr>
                                                    <th width={"30%"}>Username	</th>
                                                    <td width={"2%"}>:</td>
                                                    <td>{DataForView.username}</td>
                                                </tr>
                                                <tr>
                                                    <th width={"30%"}>Email</th>
                                                    <td width={"2%"}>:</td>
                                                    <td>{DataForView.email}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div style={{ height: "26px" }}></div>
                                    <div className="card shadow-sm">
                                        <div className="card-header bg-transparent border-0">
                                            <h3 className="mb-0"><i className="far fa-clone pr-1"></i>Other Information</h3>
                                        </div>
                                        <div className="card-body pt-0">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div className="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                    {/* <ChangePassword /> */}

                </div>
                <div className="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"></div>
            </div>
        </>
    )
}
