import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import * as Yup from "yup";
import { useFormik } from "formik";

export default function Edit(props) {
    const navigate = useNavigate();
    const user = localStorage.getItem('userName')
    const data = JSON.parse(localStorage.getItem('selectUserForEdit'));

    const signUpValidation = Yup.object({
        // name: Yup.string().min(3, "Name must be at least 3 characters").max(32, "Max name must be 32 characters").strict().trim().required('name is a required field'),
        // username: Yup.string().min(3, "Name must be at least 3 characters").max(32, "Max name must be 32 characters").required("username  is a required field"),
    });

    const { errors, handleSubmit, handleChange, values } = useFormik({
        initialValues: { ...data },

        validationSchema: signUpValidation,

        onSubmit: (values) => {
            let updatValue = {
                id: values.id,
                name: values.name,
                userName: values.username,
                email: values.email,
                status: values.status,
                role: values.role,
                updateBy: user,
                apiName: "update"
            }

            // console.log(values);
            // console.log(updatValue);
            const URL = `http://localhost/react/my-app/src/api/api.php`;
            axios.put(URL, updatValue).then((result) => {
                // console.log('axios.post > result.data>>>>> ', result.data);
                if (result.data.status === false) {
                    props.showAlert(result.data.message, "danger");
                } else {
                    navigate(`/table`);
                    props.showAlert(result.data.message, "success");
                }
            });
        }
    });

    document.title = `React Project - ${props.name}`;
    return (
        <>
            <div className="register-box my-4">
                <div className="card card-outline card-primary">
                    <div className="card-header text-center">
                        <Link to="/register" className="h1"><b>Edit Form</b></Link>
                    </div>

                    <div className="card-body">
                        <p className="login-box-msg">Register a new membership</p>

                        <form onSubmit={handleSubmit}>
                            <div className="input-group mb-3">
                                <input type="text" name="name" className="form-control" autoComplete="off" placeholder="Full name" value={values.name} onChange={handleChange} />
                            </div>
                            <div>
                                <p className='form-error' style={{ color: 'red' }}>{errors.name}</p>
                            </div>

                            <div className="input-group mb-3">
                                <input type="text" name="username" className="form-control" autoComplete="off" placeholder="Username" value={values.username} onChange={handleChange} />
                            </div>
                            <div>
                                <p className='form-error' style={{ color: 'red' }}>{errors.userName}</p>
                            </div>

                            <div className="input-group mb-3">
                                <input type="text" name="status" className="form-control" autoComplete="off" placeholder="status" value={values.status} onChange={handleChange} />
                            </div>
                            <div>
                                <p className='form-error' style={{ color: 'red' }}>{errors.status}</p>
                            </div>
                            <div className="input-group mb-3">
                                <input type="text" name="role" className="form-control" autoComplete="off" placeholder="role" value={values.role} onChange={handleChange} />
                            </div>
                            <div>
                                <p className='form-error' style={{ color: 'red' }}>{errors.status}</p>
                            </div>

                            <div className="input-group mb-3">
                                <input type="email" name="email" className="form-control" placeholder="Email" value={values.email} disabled />
                            </div>
                            <div>
                                <p className='form-error' style={{ color: 'red' }}>{errors.email}</p>
                            </div>

                            <div className="input-group mb-3">
                                <input type="hidden" name="id" className="form-control" autoComplete="off" placeholder="User ID" value={values.id} />
                            </div>

                            <div className="row">
                                <div className="col-4 social-auth-links text-center">
                                    <button type="submit" name="submit" value="submit" className="btn btn-primary btn-block">Update Data</button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}