import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useFormik } from "formik";
import * as Yup from "yup";

export default function Otp(props) {
    const navigate = useNavigate();
    const [userEmail, setUserEmail] = useState('');

    useEffect(() => {
        return () => {
            var getEmailLs = localStorage.getItem('email');
            setUserEmail(getEmailLs);
        }
    }, []);
    const otpValidation = Yup.object({
        otp: Yup.number()
            .required('ERROR: The number is required!')
            .test(
                'Is positive?',
                'ERROR: The number must be greater than 0!',
                (value) => value > 0
            )
    });
    const { values, errors, touched, handleChange, handleSubmit } = useFormik({
        initialValues: {
            opt: "",
        },
        validationSchema: otpValidation,
        onSubmit: (values) => {
            const sendUser = {
                otp: values.otp,
                email: userEmail,
                apiName: "verificationopt"
            }
            // console.log(sendUser);
            const URL = 'http://localhost/react/my-app/src/api/api.php';
            axios.post(URL, sendUser).then((result) => {
                console.log(result.data);
                if (result.data.status === true) {
                    navigate(`/resetpassword`);
                    // window.localStorage.setItem('email', result.data.email);
                    props.showAlert(result.data.message, "success");
                } else {
                    props.showAlert(result.data.message, "danger");
                }
            });
        }
    });

    document.title = `React Project - ${props.name} `;
    return (
        <div>
            <>
                <div className="login-box my-4">
                    <div className="card card-outline card-primary">
                        <div className="card-header text-center">
                            <Link to="/opt" className="h1"><b>Verify OTP</b> </Link>
                        </div>
                        <div className="card-body">
                            <p className="text-center">Enter Your OTP Code</p>
                            <form onSubmit={handleSubmit} >
                                <label htmlFor="email">OTP</label>
                                <div className="input-group mb-3">
                                    <input type="number" className="form-control" name="otp" id="otp" placeholder="Enter your OTP" onChange={handleChange} value={values.otp} />
                                </div>
                                <div>
                                    {touched.otp ? <p className='form-error' style={{ color: 'red' }}>{errors.otp} </p> : null}
                                </div>

                                <div className="row">
                                    <div className="col-4 social-auth-links text-center mt-2 mb-3">
                                        <button type="submit" name="submit" className="btn btn-primary btn-block">Verify OTP</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </>
        </div>
    )
}
