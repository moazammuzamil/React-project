import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useFormik } from "formik";
import * as Yup from "yup";

export default function ForgetPassword(props) {
    const navigate = useNavigate();
    const forgetPasswordValidation = Yup.object({
        email: Yup.string().email("Email must be a valid email i.e: xyz@m3.pk").matches(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/, "Email must be a valid email i.e: xyz@m3.pk").required(),
    });

    const { values, errors, touched, handleChange, handleSubmit } = useFormik({
        initialValues: {
            email: ""
        },
        validationSchema: forgetPasswordValidation,
        onSubmit: (values) => {
            //e.preventDefault();

            const sendUser = {
                email: values.email,
                apiName: "forgetPassword"
            }
            const URL = 'http://localhost/react/my-app/src/api/api.php';
            axios.post(URL, sendUser).then((result) => {
                console.log(result.data);
                if (result.data.status === true) {
                    navigate(`/otp`);
                    window.localStorage.setItem('email', result.data.email);
                    props.showAlert(result.data.message, "success");
                } else {
                    navigate(`/otp`);
                    props.showAlert(result.data.message, "success");
                }
            })
        }
    });

    document.title = `React Project - ${props.name} `;
    return (
        <div>
            <>
                <div className="login-box my-4">
                    <div className="card card-outline card-primary">
                        <div className="card-header text-center">
                            <Link to="/forgetpassword" className="h1"><b>Forget Password</b> </Link>
                        </div>

                        <div className="card-body">
                            <p className="login-box-msg">Enter your email start your process</p>

                            <form onSubmit={handleSubmit}  >
                                <label htmlFor="email">Email</label>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control" name="email" id="email" placeholder="Email" onChange={handleChange} value={values.email} />
                                </div>
                                <div>
                                    {touched.email ? <p className='form-error' style={{ color: 'red' }}>{errors.email} </p> : null}
                                </div>

                                <div className="row">
                                    <div className="col-4 social-auth-links text-center mt-2 mb-3">
                                        <button type="submit" name="submit" className="btn btn-primary btn-block">Send OTP</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </>
        </div>
    )
}
