import React from 'react';

export default function Home(props) {
    document.title = `React Project - ${props.name} `;
    return (
        <div className='container text-center' style={{ color: props.mode === 'dark' ? 'white' : 'black' }}><h1>Home </h1></div>
    )
}
