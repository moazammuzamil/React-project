import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import * as Yup from "yup";
import { useFormik } from "formik";

export default function Register(props) {
    const navigate = useNavigate();
    const [auth, setAuth] = useState('');

    useEffect(() => {
        return () => {
            var getUserLs = localStorage.getItem('userName');
            setAuth(getUserLs);
        }
    }, []);

    if (auth !== null) {
        navigate(`/dashboard`);
    }

    const signUpValidation = Yup.object({
        name: Yup.string().min(3, "Name must be at least 3 characters").max(32, "Max name must be 32 characters").strict().trim().required(),
        userName: Yup.string().min(3, "Name must be at least 3 characters").max(32, "Max name must be 32 characters").required("username  is a required field"),
        email: Yup.string().email().required(),
        password: Yup.string().max(20).matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, "Must contain 8 characters, one uppercase,one lowercase,one number and one specialcase character").required()
    });

    const { values, errors, handleChange, handleSubmit } = useFormik({
        initialValues: {
            name: "",
            userName: "",
            email: "",
            password: ""
        },
        validationSchema: signUpValidation,
        onSubmit: (values) => {
            const sendData = {
                name: values.name,
                userName: values.userName,
                email: values.email,
                password: values.password,
                status: 1,
                role: 0,
                apiName: "signup"
            };
            // console.log(values);
            const URL = 'http://localhost/react/my-app/src/api/api.php';
            axios.post(URL, sendData).then((result) => {
                // console.log('axios.post > result.data>>>>> ', result.data);

                if (result.data.status === false) {
                    props.showAlert(result.data.message, "danger");
                } else {
                    navigate(`/login`);
                    props.showAlert(result.data.message, "success");
                }
            });
        }
    });
    document.title = `React Project - ${props.name}`;

    return (
        <>
            <div className="register-box my-4">
                <div className="card card-outline card-primary">
                    <div className="card-header text-center">
                        <Link to="/register" className="h1"><b>Register</b></Link>
                    </div>

                    <div className="card-body">
                        <p className="login-box-msg">Register a new membership</p>

                        <form onSubmit={handleSubmit}>
                            <div className="input-group mb-3">
                                <input type="text" name="name" className="form-control" autoComplete="off" placeholder="Full name" onChange={handleChange} value={values.name} />
                            </div>
                            <div>
                                <p className='form-error' style={{ color: 'red' }}>{errors.name}</p>
                            </div>

                            <div className="input-group mb-3">
                                <input type="text" name="userName" className="form-control" autoComplete="off" placeholder="Username" onChange={handleChange} value={values.userName} />
                            </div>
                            <div>
                                <p className='form-error' style={{ color: 'red' }}>{errors.userName}</p>
                            </div>

                            <div className="input-group mb-3">
                                <input type="email" name="email" className="form-control" autoComplete="off" placeholder="Email" onChange={handleChange} value={values.email} />
                            </div>
                            <div>
                                <p className='form-error' style={{ color: 'red' }}>{errors.email}</p>
                            </div>

                            <div className="input-group mb-3">
                                <input type="password" name="password" className="form-control" autoComplete="off" placeholder="Password" onChange={handleChange} value={values.password} />
                            </div>
                            <div>
                                <p className='form-error' style={{ color: 'red' }}>{errors.password}</p>
                            </div>

                            <div className="row">
                                <div className="col-8">
                                    <div className="icheck-primary">
                                        <input type="checkbox" id="agreeTerms" name="terms" value="agree" required />
                                        <label className='mx-2' htmlFor="agreeTerms">
                                            I agree to the <a href="/">terms & conditions</a>
                                        </label>
                                    </div>
                                </div>

                                <div className="col-4 social-auth-links text-center">
                                    <button type="submit" name="submit" value="submit" className="btn btn-primary btn-block">Register</button>
                                </div>

                            </div>
                        </form>

                        <Link to="/login" className="text-center">I already have a membership</Link>
                    </div>
                </div>
            </div>
        </>
    )
}
