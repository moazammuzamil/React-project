import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useFormik } from "formik";
import * as Yup from "yup";

export default function Login(props) {
    const navigate = useNavigate();
    const [auth, setAuth] = useState('');
    const [refreshLogin, setRefreshLogin] = useState(false);

    useEffect(() => {
        return () => {
            var getUserLs = localStorage.getItem('userName')
            setAuth(getUserLs);
            setRefreshLogin(true);
        }

    }, [refreshLogin]);

    //console.log(auth);

    if (auth !== null) {
        navigate(`/dashboard`);
    }

    const signInValidation = Yup.object({
        email: Yup.string().email("Email must be a valid email i.e: xyz@m3.pk").matches(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/, "Email must be a valid email i.e: xyz@m3.pk").required(),
        password: Yup.string().max(20).matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, "Must contain 8 characters, one uppercase, one lowercase, one number and one specialcase character.").required()
    });

    const { values, errors, touched, handleChange, handleSubmit } = useFormik({
        initialValues: {
            email: "",
            password: ""
        },
        validationSchema: signInValidation,
        onSubmit: (values) => {
            //e.preventDefault();

            const sendUser = {
                email: values.email,
                password: values.password,
                apiName: "signin"
            }
            const URL = 'http://localhost/react/my-app/src/api/api.php';
            axios.post(URL, sendUser).then((result) => {
                // console.log(result.data.status);
                if (result.data.status === true) {
                    window.localStorage.setItem('userName', result.data.username);
                    window.localStorage.setItem('role', result.data.role);
                    window.localStorage.setItem('id', result.data.id);
                    window.localStorage.setItem('password', result.data.password);
                    window.localStorage.setItem('name', result.data.name);
                    window.localStorage.setItem('email', result.data.email);
                    window.localStorage.setItem('status', result.data.status);
                    navigate(`/dashboard`);
                    props.showAlert(result.data.message, "success");
                } else {
                    props.showAlert(result.data.message, "danger");
                }
            })
        }
    });

    document.title = `React Project - ${props.name} `;
    return (
        <>
            <div className="login-box my-4">
                <div className="card card-outline card-primary">
                    <div className="card-header text-center">
                        <Link to="/login" className="h1"><b>Login</b> </Link>
                    </div>

                    <div className="card-body">
                        <p className="login-box-msg">Sign in to start your session</p>

                        <form onSubmit={handleSubmit}  >
                            <label htmlFor="email">Email</label>
                            <div className="input-group mb-3">
                                <input type="text" className="form-control" name="email" id="email" placeholder="Email" onChange={handleChange} value={values.email} />
                            </div>
                            <div>
                                {touched.email ? <p className='form-error' style={{ color: 'red' }}>{errors.email} </p> : null}
                            </div>

                            <label htmlFor="password">Password</label>
                            <div className="input-group mb-3">
                                <input type="password" className="form-control" name="password" id="password" placeholder="Password" onChange={handleChange} value={values.password} />
                            </div>
                            <div>
                                {touched.password ? <p className='form-error' style={{ color: 'red' }}>{errors.password}</p> : null}
                            </div>

                            <div className="row">
                                <div className="col-8">
                                    <div className="icheck-primary">
                                        <input type="checkbox" id="remember" />
                                        <label className='mx-2' htmlFor="remember">
                                            Remember Me
                                        </label>
                                    </div>
                                </div>

                                <div className="col-4 social-auth-links text-center mt-2 mb-3">
                                    <button type="submit" name="submit" className="btn btn-primary btn-block">Sign In</button>
                                </div>
                            </div>
                        </form>

                        <div className="social-auth-links text-center mt-2 mb-3 mx-2">
                            <Link to="/forgetpassword" className="btn btn-block btn-primary">
                                <i></i> I forgot my password
                            </Link>
                            <Link to="/register" className="btn btn-block btn-danger mx-2">
                                <i></i> Register a new membership
                            </Link>
                        </div>


                    </div>
                </div>
            </div>
        </>
    )
}

