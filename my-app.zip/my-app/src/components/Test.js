import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Test(props) {
    const [name, setName] = useState('');
    const [input, setInput] = useState('');
    const [auth, setAuth] = useState('');
    const [userName, setUserName] = useState('');
    const [email, setEmail] = useState('');
    const [status, setStatus] = useState('');
    const [role, setRole] = useState('');

    useEffect(() => {
        var auth = JSON.parse(localStorage.getItem('userDetails'));
        setAuth(auth);

    }, []);
    useEffect(() => {
        return () => {
            getUserDetails();
            // console.log(JSON.stringify(localStorage.getItem('userDetails')));
            // console.log(auth.hasOwnProperty("id"));
            // console.log(auth.id);
        }
    }, []);
    const getUserDetails = async () => {

        try {
            // const $send = {apiName: "fetchuserinvoices"};
            const response = await axios.get(`http://localhost/react/my-app/src/api/testapi.php/`);
            // console.log(response.data);
            setInput(response.data);
            setName(auth[0].name);
            setUserName(auth[0].username);
            setEmail(auth[0].email);
            setStatus(auth[0].status);
            setRole(auth[0].role);
        } catch (error) {
            props.showAlert(error, "danger");
        }
    };
    return (
        <>
            <div className="register-box my-4">
                <div className="card card-outline card-primary">
                    <div className="card-header text-center">
                        <Link to="/register" className="h1"><b>Register</b></Link>
                    </div>

                    <div className="card-body">
                        <p className="login-box-msg">Register a new membership</p>

                        <form>
                            <div className="input-group mb-3">
                                <input type="text" name="name" className="form-control" autoComplete="off" placeholder="Full name" value={name} />
                            </div>

                            <div className="input-group mb-3">
                                <input type="text" name="userName" className="form-control" autoComplete="off" placeholder="Username" value={userName} />
                            </div>

                            <div className="input-group mb-3">
                                <input type="text" name="status" className="form-control" autoComplete="off" placeholder="status" value={status} />
                            </div>
                            <div className="input-group mb-3">
                                <input type="text" name="role" className="form-control" autoComplete="off" placeholder="role" value={role} />
                            </div>

                            <div className="input-group mb-3">
                                <input type="email" name="email" className="form-control" placeholder="Email" value={email} disabled />
                            </div>

                            <div className="row">
                                <div className="col-4 social-auth-links text-center">
                                    <button type="submit" name="submit" value="submit" className="btn btn-primary btn-block">Update Data</button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}
