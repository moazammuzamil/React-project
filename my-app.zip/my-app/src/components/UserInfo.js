import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function UserInfo(props) {
    const navigate = useNavigate();
    const [auth, setAuth] = useState('na');
    const [refreshNavLogout, setRefreshNavLogout] = useState(false);

    useEffect(() => {

        var getUserLs = localStorage.getItem('userName');
        setAuth(getUserLs);

    }, [refreshNavLogout]);

    // const capitalize = (auth) => {
    //     const lower = word.toLowerCase();
    //     return lower.charAt(0).toUpperCase() + lower.slice(1);
    // }

    const logOut = () => {
        window.localStorage.removeItem('status', 'userName');
        window.localStorage.clear();
        setRefreshNavLogout(true);
        props.callBack();
        props.refresh();
        navigate(`/login`);
    }

    return (
        <div className="dropdown mx-2">
            <button className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                {auth}
            </button>

            <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                <li><Link className="dropdown-item" to="/profile">Profile</Link></li>
                <li><Link className="dropdown-item" to="/ChangePassword">Reset Password</Link></li>
                <li><Link className="dropdown-item" aria-current="page" to="/" onClick={logOut}>Logout</Link></li>
            </ul>
        </div>
    )
}
