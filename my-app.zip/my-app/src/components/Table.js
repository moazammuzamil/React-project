import axios from 'axios';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { useNavigate } from 'react-router-dom';
import { Modal, ModalHeader, ModalBody } from 'reactstrap';

export default function Table(props) {
    const [userDetails, setUserDetails] = useState([]);
    const [auth, setAuth] = useState('na');
    // const [search, setSearch] = useState(null);
    // const [filterUser, setFilterUser] = useState([]);
    const [modal, setModal] = useState(false);
    const [userId, setUserId] = useState(0);
    const [refreshModal, setRefreshModal] = useState(false);
    // const [open, setOpen] = useState(false);
    var getUserLs = localStorage.getItem('userName');

    const navigate = useNavigate();

    // if (auth !== null) {
    //     navigate(`/table`);
    // } else {
    //     navigate(`/login`);
    // }

    useEffect(() => {
        return () => {
            setAuth(getUserLs);
        }
    }, []);

    // useEffect(() => {
    //     const result = userDetails.filter(user => {
    //         return user.name.toLowerCase().match(search.toLowerCase());
    //     });
    //     setFilterUser(result);
    // }, [search]);

    useEffect(() => {
        return () => {
            getUserDetails();
        }
    }, [refreshModal]);

    const viewUser = async (id) => {
        try {
            const sendData = {
                apiName: "fetchdata"
            };
            const URL =("http://localhost/react/my-app/src/api/getUserById.php/" + id)
            const response = await axios.get(URL, sendData);
            window.localStorage.setItem('userDetailsView', JSON.stringify(response.data[0]));

            navigate(`/userprofile`);
        } catch (error) {
            props.showAlert(error, "danger");
        }
    }

    const getUserDetails = async () => {
        try {

            // const $send = {apiName: "fetchuserinvoices"};
            const response = await axios.get("http://localhost/react/my-app/src/api/testapi.php");
            // console.log("getUserDetails > response.data >>>",response.data);
            setUserDetails(response.data);
            // setFilterUser(response.data);
        } catch (error) {
            props.showAlert(error, "danger");
        }
    };

    const selectUser = async (id) => {
        try {
            const response = await axios.get("http://localhost/react/my-app/src/api/getUserById.php/" + id);
            window.localStorage.setItem('selectUserForEdit', JSON.stringify(response.data[0]));

            navigate(`/edit`);
        } catch (error) {
            props.showAlert(error, "danger");
        }
    }

    // useEffect(() => {
    //     get();
    // }, []);

    const userDelete = () => {
        const sendUser = {
            id: userId,
            apiName: "delete"
        }
        const URL = 'http://localhost/react/my-app/src/api/api.php';
        axios.post(URL, sendUser).then((result) => {
            // console.log(result.data.status);
            if (result.data.status === true) {
                setRefreshModal(true);
                props.showAlert(result.data.message, "success");
                setModal(false);
            } else {
                props.showAlert(result.data.message, "danger");
            }
        })
    };

    const colums = [
        {
            name: "Name",
            selector: (row) => row.name,
            sortable: true,
            sortField: 'name',
        },
        {
            name: "User Name",
            selector: (row) => row.username,
            sortable: true,
            sortField: 'user name',

        },
        {
            name: "Email",
            selector: (row) => row.email,
            sortable: true,
            sortField: 'email',

        },
        {
            name: "Status",
            selector: (row) => row.status,
            sortable: true,
            sortField: 'status',

        },
        {
            name: "Role",
            selector: (row) => row.role,
            sortable: true,
            sortField: 'role',
        },
        {
            name: "Action",
            cell: (row) => <span>
                <button className='btn btn-sm btn-primary mx-1' onClick={() => viewUser(row.id)}>View</button>
                <button className='btn btn-sm btn-primary mx-1' onClick={() => selectUser(row.id)} >Edit</button>
                <button className='btn btn-sm btn-primary mx-1' onClick={() => {
                    setModal(true);
                    setUserId(row.id);
                }} >Delete</button>
            </span>
        },
    ];

    const customStyles = {
        Header: {
            style: { backgroundColor: '#042745' },
        },
        rows: {
            style: {
                minHeight: '72px', // override the row height
            },
        },
        headCells: {
            style: {
                paddingLeft: '8px', // override the cell padding for head cells
                paddingRight: '8px',
            },
        },
        cells: {
            style: {
                paddingLeft: '8px', // override the cell padding for data cells
                paddingRight: '8px',
            },
        },
    };

    document.title = `React Project - ${props.name}`;
    // console.log(colums.ID);

    return (
        <>
            <Modal className="modal-dialog modal-dialog-centered" isOpen={modal} toggle={() => { setModal(!modal) }}>
                <ModalHeader toggle={() => { setModal(!modal) }}>
                    Alert
                </ModalHeader>
                <ModalBody>
                    <p>are you sure you want to permanently delete this user?</p>
                    <button type="button" className="btn btn-success" onClick={(id) => userDelete()}>OK</button>
                </ModalBody>
            </Modal>

            <div className='container ' style={{ color: props.mode === 'dark' ? 'white' : 'black' }}><h4>Welcome {auth}!</h4></div>
            <div>
                <DataTable
                    title='User Details'
                    columns={colums}
                    data={userDetails}
                    pagination
                    fixedHeader
                    paginationRowsPerPageOptions={[5, 10, 25, 50, 100]}
                    highlightOnHover
                    // selectableRows
                    actions={<button className='btn btn-primary'>Add User</button>}
                    subHeader
                    customStyles={customStyles}
                // subHeaderComponent={<input type="text" placeholder='Search here' name='search' className='w-25 form-control' value={search} onchange={(e) => setSearch(e.target.value)} />}
                />

            </div>
        </>
    )
}
