import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';

export default function Protected(props) {
  const {Component} = props;
  let login = localStorage.getItem('status');
  const navigate = useNavigate(); 
  useEffect(()=>{
    return () => {
      if(login != true){
        navigate('/login');
      }
    }
  })
  return (
    <div>
      <Component />
    </div>
  )
}
