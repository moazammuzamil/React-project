import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useFormik } from "formik";
import * as Yup from "yup";

export default function ResetPassword(props) {
    const navigate = useNavigate();
    const [userEmail, setUserEmail] = useState('');
    const [userID, setUserID] = useState('');

    useEffect(() => {
        var getEmailLs = localStorage.getItem('email');
        var getIdLs = localStorage.getItem('id');
        setUserEmail(getEmailLs);
        setUserID(getIdLs);
    }, []);

    const resetPasswordValidation = Yup.object({
        oldPassword: Yup.string().max(20).matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, "Must contain 8 characters, one uppercase, one lowercase, one number and one specialcase character.").required(),
        password: Yup.string().max(20).matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, "Must contain 8 characters, one uppercase, one lowercase, one number and one specialcase character.").required(),
        cPassword: Yup.string().required().oneOf([Yup.ref("password"), null], "Password must match")
    });

    const { values, errors, touched, handleChange, handleSubmit } = useFormik({
        initialValues: {
            oldPassword: "",
            password: "",
            cPassword: "",
            email: "",
            id: ""
        },
        validationSchema: resetPasswordValidation,
        onSubmit: (values) => {

            const sendUser = {
                email: userEmail,
                id: userID,
                password: values.password,
                oldpassword: values.oldPassword,
                apiName: "oldpassword"
            }
            console.log(sendUser);
            const URL = 'http://localhost/react/my-app/src/api/api.php';
            axios.post(URL, sendUser).then((result) => {
                // console.log(result.data.status);
                if (result.data.status === true) {
                    navigate(`/`);
                    props.showAlert(result.data.message, "success");
                } else {
                    props.showAlert(result.data.message, "danger");
                }
            })
        }
    });

    document.title = `React Project - ${props.name} `;
    return (
        <>
            <div className="login-box my-4">
                <div className="card card-outline card-primary">
                    <div className="card-header text-center">
                        <Link to="/resetpassword" className="h1"><b>Change Password</b> </Link>
                    </div>

                    <div className="card-body">

                        <form onSubmit={handleSubmit}  >

                            <label htmlFor="password">Old Password</label>
                            <div className="input-group mb-3">
                                <input type="password" className="form-control" name="oldPassword" id="oldPassword" placeholder="Old Password" onChange={handleChange} value={values.oldPassword} />
                            </div>
                            <div>
                                {touched.oldPassword ? <p className='form-error' style={{ color: 'red' }}>{errors.oldPassword}</p> : null}
                            </div>

                            <label htmlFor="password">Password</label>
                            <div className="input-group mb-3">
                                <input type="password" className="form-control" name="password" id="password" placeholder="Password" onChange={handleChange} value={values.password} />
                            </div>
                            <div>
                                {touched.password ? <p className='form-error' style={{ color: 'red' }}>{errors.password}</p> : null}
                            </div>

                            <label htmlFor="cpassword">Comfrim Password</label>
                            <div className="input-group mb-3">
                                <input type="password" className="form-control" name="cPassword" id="cpassword" placeholder="Comfrim Password" onChange={handleChange} value={values.cPassword} />
                            </div>
                            <div>
                                {touched.cPassword ? <p className='form-error' style={{ color: 'red' }}>{errors.cPassword}</p> : null}
                            </div>

                            <div className="row">
                                <div className="col-8">
                                </div>
                                <div className="col-4 social-auth-links text-center mt-2 mb-3">
                                    <button type="submit" name="submit" className="btn btn-primary btn-block">Change Password</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </>
    )
}
