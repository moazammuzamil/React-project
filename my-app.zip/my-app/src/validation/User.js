import * as Yup from "yup";

const signUpValidation = Yup.object({
    name: Yup.string().min(3,"Name must be at least 3 characters").max(32,"Max Name must be 32 characters").strict().trim().required(),
    userName: Yup.string().min(3,"Name must be at least 3 characters").max(32,"Max Name must be 32 characters").required() ,
    email: Yup.string().email().required(),
    password: Yup.string().max(20).matches(/^(?=.*[A-Za-z])(?=.*[!@#$%^&*?])[A-Za-z\d!@#$%^&*?]{8,}$/,"Must Contain 8 Characters, One Uppercase,One Lowercase,One Number and One Specialcase Character").required()
});