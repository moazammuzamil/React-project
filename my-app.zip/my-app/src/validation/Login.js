import * as Yup from "yup";

export const signInValidation = Yup.object({
    email: Yup.string().email().required(),
    password: Yup.string().max(20).matches(/^(?=.*[A-Za-z])(?=.*[!@#$%^&*?])[A-Za-z\d!@#$%^&*?]{8,}$/,"Must Contain 8 Characters, One Uppercase,One Lowercase,One Number and One Specialcase Character").required()
});