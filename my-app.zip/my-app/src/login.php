<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization, X-Requested-With");

$conn = mysqli_connect('localhost', 'root', '', 'react_form') or die("not connected");

$data = json_decode(file_get_contents("php://input"));

$email = $data->email;
$password = $data->password;




if($email && $password){
$sql =  "SELECT * FROM  react_register WHERE email = '".$email."'  AND  password = '".$password."'";
$result = mysqli_query($conn, $sql);

$num = mysqli_num_rows($result);
$rs = mysqli_fetch_array($result);

if($num >= 1){
   http_response_code(200);
   $outp ="";

$outp  .= '{"email":"' .$rs["email"].'",';
$outp  .= '"name":"' .$rs["name"].'",';
$outp  .= '"Status":"200"}';

   echo $outp;
}else{
   http_response_code(202);
} 
}
?>