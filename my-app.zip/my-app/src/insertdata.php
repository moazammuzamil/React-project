<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization, X-Requested-With");

$data = json_decode(file_get_contents("php://input"));

$name = $data->name;
$user_name = $data->user_name;
$email = $data->email;
$password = $data->password;


$conn = mysqli_connect('localhost', 'root', '', 'react_form') or die("not connected");

if($name && $user_name && $email && $password){
$sql =  "INSERT INTO  react_register (name,username, email,password) VALUES ('$name', '$user_name', '$email', '$password')";
$result = mysqli_query($conn, $sql);
if($result){
    $response['data'] = array(
        'status' => 'valid'
    );
    echo json_encode($response);
}else{
    $response['data'] = array(
        'status' => 'invalid'
    );
    echo json_encode($response);
} 
}
?>