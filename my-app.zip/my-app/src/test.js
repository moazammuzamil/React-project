const res = (result)=>{
    if(result.data.Status === 'Invalid'){
        alert('Invalid User');
    }else{
        history
        (`/Login`);
    }
}
let data={
    name : "moazam",
    Status : "invalid",
}
console.log(res(data));