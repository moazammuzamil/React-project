<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST,GET,PUT");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization, X-Requested-With");

$conn = mysqli_connect('localhost', 'root', '', 'react_form') or die("not connected");

$data = json_decode(file_get_contents("php://input"));

$apiName = strtolower($data->apiName);

if ($apiName === "signin") {
    $email = $data->email;
    $password = $data->password;

    if ($email && $password) {
        $sql = "SELECT * FROM  react_register WHERE email = '" . $email . "'  AND  password = '" . $password . "'";
        $result = mysqli_query($conn, $sql);
        $num = mysqli_num_rows($result);
        $rs = mysqli_fetch_array($result);
        // echo $rs;
        if ($num >= 1) {
            if ($rs["status"] == 1) {
                echo json_encode($response['data'] = array('message' => 'login successfully', 'username' => $rs["username"], 'id' => $rs["id"], 'role' => $rs["role"], 'email' => $rs["email"], 'password' => $rs["password"], 'name' => $rs["name"], 'status' => true));
                exit();
            } else if ($rs["status"] == 0) {
                echo json_encode($response['data'] = array('message' => 'your account is deactivate', 'status' => false));
            } else if ($rs["status"] == 2) {
                echo json_encode($response['data'] = array('message' => 'your account is blocked', 'status' => false));
            }
        } else {
            echo json_encode($response['data'] = array('message' => 'login failed', 'status' => false));
            exit();
        }
    }
} else if ($apiName === "signup") {
    $name = $data->name;
    $userName = $data->userName;
    $email = $data->email;
    $password = $data->password;
    $status = $data->status;
    $role = $data->role;
    if ($name && $userName && $email && $password) {
        $duplicate = mysqli_query($conn, "SELECT * FROM react_register WHERE username = '$userName' OR email ='$email'");
        if (mysqli_num_rows($duplicate) > 0) {
            echo json_encode($response['data'] = array('message' => 'this username and email already taken', 'status' => false));
        } else {
            $sql = "INSERT INTO  react_register (name,username,email,password,status,role) VALUES ('$name', '$userName', '$email', '$password', '$status', '$role')";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                echo json_encode($response['data'] = array('message' => 'user register successfully', 'status' => true));
                exit();
            } else {
                echo json_encode($response['data'] = array('message' => 'user registertion failed', 'status' => false));
                exit();
            }
        }
    }
} else if ($apiName === "forgetpassword") {
    $email = $data->email;

    if ($email) {
        $sql = "SELECT * FROM  react_register WHERE email = '" . $email . "'";
        $result = mysqli_query($conn, $sql);

        $num = mysqli_num_rows($result);
        $rs = mysqli_fetch_array($result);

        if ($num >= 1) {
            $otp = rand(100000, 999999);
            // $massage = 'your password reset otp is '.$otp;
            // $to = $email;
            // $subject= "OTP Verifcation";
            // $from = "intern.moazam@m3tech.com.pk";
            // $header ="From : $from ";
            // mail($to, $subject,$massage,$header); 
            mysqli_query($conn, "UPDATE react_register SET otp ='" . $otp . "' WHERE email='" . $email . "'");

            // stmpMailer(h,vv, g);
            echo json_encode($response['data'] = array('message' => 'send your otp please check your email inbox', 'email' => $rs["email"], 'status' => true));
            exit();
        } else {
            echo json_encode($response['data'] = array('message' => 'send your otp please check your email inbox', 'status' => false));
            exit();
        }
    }

    // funcation stmpMailer($otp,$subject,$msg){
    //     require 'vendor/autoload.php';
    //     use PHPMailer\PHPMailer\PHPMailer;
    //     $mail = new PHPMailer;
    //     $mail->isSMTP();
    //     $mail->SMTPDebug = 2;
    //     $mail->Host = 'smtp.hostinger.com';
    //     $mail->Port = 587;
    //     $mail->SMTPAuth = true;
    //     $mail->Username = 'aaaadvisory1967@gmail.com';
    //     $mail->Password = 'AAA@1967';
    //     $mail->setFrom('mymail@myawesomedomain.tld', 'Your Name');
    //     $mail->addReplyTo('mymail@myawesomedomain.tld', 'Your Name');
    //     $mail->addAddress('recipient@domain.tld', 'Receiver Name');
    //     $mail->Subject = 'Checking if PHPMailer works';
    //     $mail->msgHTML(file_get_contents('message.html'), __DIR__);
    //     $mail->Body = 'This is just a plain text message body';
    //     //$mail->addAttachment('attachment.txt');
    //     if (!$mail->send()) {
    //         echo 'Mailer Error: ' . $mail->ErrorInfo;
    //     } else {
    //         echo 'The email message was sent.';
    //     }
    // }
} else if ($apiName === "verificationopt") {
    $otp = $data->otp;
    $email = $data->email;
    if ($otp && $email) {
        $sql = "SELECT * FROM  react_register WHERE email = '" . $email . "'  AND  otp = '" . $otp . "'";
        $result = mysqli_query($conn, $sql);
        $num = mysqli_num_rows($result);
        $rs = mysqli_fetch_array($result);
        if ($num >= 1) {
            mysqli_query($conn, "UPDATE react_register SET otp =' ' WHERE email='" . $email . "'");
            echo json_encode($response['data'] = array('message' => 'Change your password', 'status' => true));
            exit();
        } else {
            echo json_encode($response['data'] = array('message' => 'please enter valid otp', 'status' => false));
            exit();
        }
    }
} else if ($apiName === "resetpassword") {
    $password = $data->password;
    $email = $data->email;
    if ($email && $password) {
        $sql = "SELECT * FROM  react_register WHERE email = '" . $email . "'";
        $result = mysqli_query($conn, $sql);

        $num = mysqli_num_rows($result);
        $rs = mysqli_fetch_array($result);

        if ($num >= 1) {
            mysqli_query($conn, "UPDATE react_register SET password = '" . $password . "' WHERE email = '" . $email . "'");
            echo json_encode($response['data'] = array('message' => 'Change your password', 'status' => true));
            exit();
        } else {
            echo json_encode($response['data'] = array('message' => 'Change password failed', 'status' => false));
            exit();
        }
    }
} else if ($apiName === "oldpassword") {
    $password = $data->password;
    $oldpassword = $data->oldpassword;
    $email = $data->email;
    $id = $data->id;
    // echo $data;
    if ($email && $password && $oldpassword && $id) {
        $sql = "SELECT * FROM  react_register WHERE email = '" . $email . "' AND password = '" . $oldpassword . "'";
        $result = mysqli_query($conn, $sql);

        $num = mysqli_num_rows($result);
        $rs = mysqli_fetch_array($result);

        if ($num >= 1) {
            mysqli_query($conn, "UPDATE react_register SET password = '" . $password . "' WHERE email = '" . $email . "' AND password = '" . $oldpassword . "'");
            echo json_encode($response['data'] = array('message' => 'Change your password', 'status' => true));
            exit();
        } else {
            echo json_encode($response['data'] = array('message' => 'Change password failed', 'status' => false));
            exit();
        }
    }
} else if ($apiName === "delete") {
    $id = $data->id;
    $sql = "DELETE FROM react_register WHERE id = '" . $id . "'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo json_encode(array('message' => 'data delete successfully .', 'status' => true));
    } else {
        echo json_encode(array('message' => 'data not delete.', 'status' => false));
    }
} else if ($apiName === "update") {
    $name = $data->name;
    $userName = $data->userName;
    $status = $data->status;
    $role = $data->role;
    $email = $data->email;
    $updateBy = $data->updateBy;
    $id = $data->id;
    $update = date('Y-m-d h:m:s');
    // die($status);
    if ($apiName = "update") {
        $sql = "SELECT * FROM  react_register WHERE email = '" . $email . "'";
        $result = mysqli_query($conn, $sql);

        $num = mysqli_num_rows($result);
        $rs = mysqli_fetch_array($result);

        if ($num = 1) {
            $sql = "UPDATE react_register SET name = '" . $name . "', userName = '" . $userName . "',status = '" . $status . "', role ='" . $role . "',updateBy='" . $updateBy . "', updatedAt = '" . $update . "' WHERE   id = '" . $id . "'";
            mysqli_query($conn, $sql);

            echo json_encode($response['data'] = array('message' => 'Update your Data', 'status' => true));
            exit();
        } else {
            echo json_encode($response['data'] = array('message' => 'Update failed', 'status' => false));
            exit();
        }
    } else {
        die('Data not updated');
    }
} else if ($apiName === "fetchdata") {

    $uriSegments = explode("/", parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
    $id = $uriSegments[6];

    $sql = "SELECT id,name,username,email,status,role,comments,updatedAt,createdBy,role,updateBy,createdAt FROM react_register where id = '" . $id . "'";

    $result = mysqli_query($conn, $sql) or die("SQL Query Feiled.");
    if (mysqli_num_rows($result) > 0) {
        $output = mysqli_fetch_all($result, MYSQLI_ASSOC);
        echo json_encode($output);
    } else {
        echo json_encode(array('message' => 'No Record Found', 'status' => false));
    }
}

?>